<?php $__env->startSection('title'); ?>
    Login DUDI | Tracer Study
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-col lg:flex-row h-screen items-center">
        <!-- Bagian kiri -->
        <div class="bg-primary-50 hidden lg:flex justify-center items-center w-full lg:w-1/2 xl:w-2/3 h-screen">
            <img data-aos="zoom-in" class="w-2/3" src="<?php echo e(asset('assets/img/illustrations/Meeting-bro.svg')); ?>">
        </div>

        <!-- Bagian kanan -->
        <div class="bg-white w-full lg:w-1/2 xl:w-1/3 h-screen lg:h-auto flex items-center lg:px-7 sm:px-32">
            <div data-aos="fade-up" class="p-6 lg:p-10 xl:p-12 w-full">
                <!-- Header -->
                <div class="flex justify-center items-center mb-8">
                    <img class="h-20 w-20
                    " src="<?php echo e(asset('assets/logo/logo.png')); ?>" alt="">
                    <div class="flex flex-col">
                        <h1 class="text-3xl text-secondary font-bold">Tracer Study</h1>
                        <h1 class="text-3xl text-primary font-bold">SMK Muhammadiyah Loa Janan</h1>
                    </div>
                </div>
                <form action="<?php echo e(route('auth.login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4">
                        <label for="email" class="label">Email</label>
                        <input type="email" id="email" name="email" placeholder="Pamapersada5@gmail.com"
                            class="form-control focus:shadow-outline <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autofocus>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="invalid-feedback">
                                <span><?php echo e($message); ?></span>
                            </label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <label for="password" class="label">Password</label>
                        <input type="password" id="password" name="password" placeholder="············"
                            class="form-control focus:shadow-outline <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="invalid-feedback">
                                <span><?php echo e($message); ?></span>
                            </label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-8">
                        <label for="remember" class="inline-flex items-center">
                            <input type="checkbox" id="remember" name="remember" class="form-checkbox">
                            <span class="ml-2 text-gray-700">Remember Me</span>
                        </label>
                    </div>
                    <button type="submit" class="btn btn-primary w-full mb-4">Masuk</button>
                    <a href="/" class="btn btn-outline-secondary w-full">Kembali</a>
                </form>
                <hr class="my-8">
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/pages/auth/dudi/login.blade.php ENDPATH**/ ?>