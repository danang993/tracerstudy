<div class="mb-4 select" data-select2-id="43">
    <label class="form-label"><?php echo e($question->name); ?></label>
    <select class="form-control select2bs4 select2-hidden-accessible" style="width: 100%;" tabindex="-1"
        aria-hidden="true">
        <?php $__currentLoopData = $question->optionInputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($option->id); ?>"><?php echo e($option->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

</div>
<?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/partials/dash/question/select.blade.php ENDPATH**/ ?>