<div class="w-full p-5">
    <style>
        .swal2-styled.swal2-confirm:focus {
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
        }

        .swal2-confirm.swal2-styled {
            border-radius: 0.25rem;
            border-width: 2px;
            border-style: solid;
            --tw-border-opacity: 1;
            border-color: rgb(255 106 0 / var(--tw-border-opacity));
            --tw-bg-opacity: 1;
            background-color: rgb(255 106 0 / var(--tw-bg-opacity));
            --tw-text-opacity: 1;
            color: rgb(255 255 255 / var(--tw-text-opacity));
            --tw-shadow: 0 0.125rem 0.25rem 0 rgba(153, 255, 105, 0.4);
            --tw-shadow-colored: 0 0.125rem 0.25rem 0 var(--tw-shadow-color);
            box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
        }
    </style>
    <div class="w-full mt-5 flex flex-col items-center">
        <a href="/">
            <img class="w-28 mb-20 logo-shadow p-5 rounded-full bg-white " src="<?php echo e(asset('assets/logo/logo.png')); ?>"
                alt="SMk Muhammadiyah Loa Janan">
        </a>
        <div class="stepwizard mb-10">
            <?php if(!$isFinished || $currentStep != 0): ?>
            <?php endif; ?>
            <div class="stepwizard-row">
                <div class="stepwizard-step">
                    <button type="button" wire:click="currentStepChanged(1)"
                        class="btn <?php echo e($currentStep >= 1 || $currentStep == 0 ? 'btn-primary' : 'btn-disable'); ?> rounded-full">1</button>
                    <p class="mt-2 <?php echo e($currentStep >= 1 || $currentStep == 0 ? 'text-primary' : 'text-gray-600'); ?>">
                        Data
                        Umum</p>
                </div>
                <div class="stepwizard-step">
                    <button type="button" wire:click="currentStepChanged(2)"
                        class="btn <?php echo e($currentStep >= 2 || $currentStep == 0 ? 'btn-primary' : 'btn-disable cursor-default'); ?> rounded-full"
                        <?php echo e($currentStep >= 2 || $currentStep == 0 ? '' : 'disabled'); ?>>2</button>
                    <p class="mt-2 <?php echo e($currentStep >= 2 || $currentStep == 0 ? 'text-primary' : 'text-gray-600'); ?>">
                        Pertanyaan Survey</p>
                </div>
                <div class="stepwizard-step">
                    <button type="button"
                        class="btn <?php echo e($currentStep == 3 || $currentStep == 0 ? 'btn-primary' : 'btn-disable'); ?> rounded-full cursor-default"
                        <?php echo e($currentStep >= 3 || $currentStep == 0 ? '' : 'disabled'); ?>>3</button>
                    <p class="mt-2 <?php echo e($currentStep == 3 || $currentStep == 0 ? 'text-primary' : 'text-gray-600'); ?>">
                        Feed
                        Back</p>
                </div>
            </div>
        </div>
    </div>
    <div class="border-solid border-t-4 border-primary rounded-xl shadow-xl card">
        <div class="card-body px-10">
            <?php if($isFinished && $currentStep == 0): ?>
                <div class="bg-green-100 rounded p-5 border border-solid border-green-200 mb-10 mt-5">
                    <h1 class="text-xs sm:text-lg text-green-700">Selamat Anda telah menyelesaikan Tracer Study, kami
                        harap kalian
                        sehat
                        selalu dan
                        tidak menjadi
                        beban orang tua!</h1>
                </div>
                <div class="flex justify-center mb-10">
                    <img class="w-1/2" src="<?php echo e(asset('assets/img/illustrations/Enthusiastic-bro.png')); ?>">
                </div>
            <?php endif; ?>
            <?php if($currentStep == 1): ?>
                <form wire:submit.prevent="firstStepSubmit">
                    <div class="mb-4">
                        <label class="label">
                            <span class="label-text">Nama Alumni</span>
                        </label>
                        <input type="text" placeholder="Nama Alumni" class="form-control"
                            value="<?php echo e($alumni->name); ?>" disabled />
                    </div>
                    <div class="mb-4">
                        <label class="label">
                            <span class="label-text">NIK</span>
                        </label>
                        <input type="text" placeholder="NIK" class="form-control" value="<?php echo e($alumni->nik); ?>"
                            disabled />
                    </div>
                    <div class="mb-4">
                        <label class="label">
                            <span class="label-text">Email</span>
                        </label>
                        <input type="email" placeholder="Email"
                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="email"
                            wire:model="email" />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="invalid-feedback">
                                <span><?php echo e($message); ?></span>
                            </label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <label class="label">
                            <span class="label-text">Jurusan</span>
                        </label>
                        <select class="form-select <?php $__errorArgs = ['major'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="major">
                            <option disabled selected value="">Pilih Jurusan</option>
                            <?php $__currentLoopData = $majors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $major): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($major->id); ?>"><?php echo e($major->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['major'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="invalid-feedback">
                                <span><?php echo e($message); ?></span>
                            </label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <label class="label">
                            <span class="label-text">Alamat</span>
                        </label>
                        <textarea type="text" placeholder="Alamat" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model="address"></textarea>
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="invalid-feedback">
                                <span><?php echo e($message); ?></span>
                            </label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <label class="label">
                            <span class="label-text">Tanggal Lahir</span>
                        </label>
                        <input type="date" placeholder="Tanggal Lahir"
                            class="form-control form-date <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model="birth_date" />
                        <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="invalid-feedback">
                                <span><?php echo e($message); ?></span>
                            </label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                        <label class="label">
                            <span class="label-text">Nomer Handphone</span>
                        </label>
                        <input type="text" placeholder="Nomer HP"
                            class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer="phone" />
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="invalid-feedback">
                                <span><?php echo e($message); ?></span>
                            </label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="flex mt-10 justify-end">
                        <button type="submit" class="group btn btn-active btn-primary text-white w-full xs:w-auto">
                            <span class="sm:inline-block sm:mr-1 align-middle">Lanjut</span>
                            <i class="bx bx-chevron-right bx-sm me-sm-n2 group-hover:animate-pulse"></i>
                        </button>
                    </div>
                </form>
            <?php endif; ?>
            <?php if($currentStep == 2): ?>
                <form wire:submit.prevent="secondStepSubmit">
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($question->category_id == 4): ?>
                            <?php
                                // $answer = $answers->where('question_id', $question->id)->first();
                                // $fill = $answer->fill ?? '';
                                $fill = $question->answers[$key]->fill ?? '';
                            ?>
                            <?php echo $__env->renderWhen($question->typeInput->name == 'text', 'partials.field.text', [
                                'question' => $question,
                                'fill' => $fill,
                                'wireModel' => 'survey.' . $question->id,
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                            <?php echo $__env->renderWhen($question->typeInput->name == 'select', 'partials.field.select', [
                                'question' => $question,
                                'fill' => $fill,
                                'wireModel' => 'survey.' . $question->id,
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                            <?php echo $__env->renderWhen(
                                $question->typeInput->name == 'checkbox',
                                'partials.question.checkbox',
                                [
                                    'question' => $question,
                                    'fill' => $fill,
                                    'wireModel' => 'survey.' . $question->id,
                                ]
                            , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                            <?php echo $__env->renderWhen($question->typeInput->name == 'radio', 'partials.field.radio', [
                                'question' => $question,
                                'fill' => $fill,
                                'wireModel' => 'survey.' . $question->id,
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                            <?php echo $__env->renderWhen($question->typeInput->name == 'date', 'partials.field.date', [
                                'question' => $question,
                                'wireModel' => 'survey.' . $question->id,
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex mt-10 justify-between flex-col-reverse xs:flex-row gap-5">
                        <div class="btn btn-outline-secondary xs:btn-secondary mr-4 group w-full xs:w-auto"
                            wire:click="currentStepChanged(1)">
                            <i class="bx bx-chevron-left bx-sm me-sm-n2 group-hover:animate-pulse"></i>
                            <span class="sm:inline-block sm:mr-1 align-middle">Kembali</span>
                        </div>
                        <button type="submit" class="group btn btn-active btn-primary text-white w-full xs:w-auto">
                            <span class="sm:inline-block sm:mr-1 align-middle">Dikit Lagi</span>
                            <i class="bx bx-chevron-right bx-sm me-sm-n2 group-hover:animate-pulse"></i>
                        </button>
                    </div>
                </form>
            <?php endif; ?>
            <?php if($currentStep == 3): ?>
                <form wire:submit.prevent="thirdStepSubmit">
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($question->category_id == 5): ?>
                            <?php
                                // $answer = $answers->where('question_id', $question->id)->first();
                                // $fill = $answer->fill ?? '';
                                $fill = $question->answers[$key]->fill ?? '';
                            ?>
                            <?php echo $__env->renderWhen($question->typeInput->name == 'text', 'partials.field.text', [
                                'question' => $question,
                                'fill' => $fill,
                                'wireModel' => 'survey.' . $question->id,
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                            <?php echo $__env->renderWhen($question->typeInput->name == 'select', 'partials.field.select', [
                                'question' => $question,
                                'fill' => $fill,
                                'wireModel' => 'survey.' . $question->id,
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                            <?php echo $__env->renderWhen($question->typeInput->name == 'checkbox', 'partials.field.checkbox', [
                                'question' => $question,
                                'fill' => $fill,
                                'wireModel' => 'survey.' . $question->id,
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                            <?php echo $__env->renderWhen($question->typeInput->name == 'radio', 'partials.field.radio', [
                                'question' => $question,
                                'fill' => $fill,
                                'wireModel' => 'survey.' . $question->id,
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                            <?php echo $__env->renderWhen($question->typeInput->name == 'date', 'partials.field.date', [
                                'question' => $question,
                                'wireModel' => 'survey.' . $question->id,
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex justify-between mt-10 flex-col-reverse xs:flex-row gap-5">
                        <div class="btn btn-outline-secondary xs:btn-secondary mr-4 group w-full xs:w-auto"
                            wire:click="currentStepChanged(2)">
                            <i class="bx bx-chevron-left bx-sm me-sm-n2 group-hover:animate-pulse"></i>
                            <span class="sm:inline-block sm:mr-1 align-middle">Kembali</span>
                        </div>
                        <button type="submit" class="group btn btn-active btn-primary text-white w-full xs:w-auto">
                            <span class="sm:inline-block sm:mr-1 align-middle">Yak Nice!</span>
                            <i class="bx bx-chevron-right bx-sm me-sm-n2 group-hover:animate-pulse"></i>
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
    <div class="row mt-12 justify-center xs:justify-end flex-col xs:flex-row-reverse px-14 gap-5">
        <?php if($currentStep == 0): ?>
            <button type="button" class="btn btn-warning md:ml-10 w-full xs:w-auto"
                wire:click="currentStepChanged(1)">
                <span>Update Data Lagi</span>
                <i class='ml-1 bx bx-refresh text-xl'></i>
            </button>
        <?php endif; ?>
        <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger w-full xs:w-auto">
            Logout
        </a>
    </div>
    <?php if(session()->has('message')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: "<?php echo e(session('message')); ?>",
                showConfirmButton: true,
            })
        </script>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/livewire/form-alumni.blade.php ENDPATH**/ ?>