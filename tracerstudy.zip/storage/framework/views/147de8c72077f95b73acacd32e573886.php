<aside id="layout-menu" class="layout-menu-horizontal menu-horizontal  menu bg-menu-theme flex-grow-0">
    <div class="container-xxl d-flex h-100">
        <ul class="menu-inner">
            <!-- Dashboards -->
            <li class="menu-item <?php echo e(is_route('admin', 'active')); ?>">
                <a href="<?php echo e(route('admin')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bxs-dashboard"></i>
                    <div data-i18n="Dashboard">Dashboard</div>
                </a>
            </li>
            <!-- Form Pertanyaan -->
            <li class="menu-item <?php echo e(is_route('admin.question', 'active')); ?>">
                <a href="<?php echo e(route('admin.question')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-book-content"></i>
                    <div data-i18n="Form Kuisioner">Form Kuisioner</div>
                </a>
            </li>
            <!-- Manajemen Alumni -->
            <li class="menu-item <?php echo e(is_route('user.index', 'active')); ?>">
                <a href="<?php echo e(route('user.index')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-user"></i>
                    <div data-i18n="Manajemen Alumni">Manajemen Alumni</div>
                </a>
            </li>
            <!-- Manajemen Jurusan -->
            <li class="menu-item <?php echo e(is_route('major.index', 'active')); ?>">
                <a href="<?php echo e(route('major.index')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-blanket"></i>
                    <div data-i18n="Manajemen Jurusan">Manajemen Jurusan</div>
                </a>
            </li>
            
        </ul>
    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/partials/dash/sidebar.blade.php ENDPATH**/ ?>