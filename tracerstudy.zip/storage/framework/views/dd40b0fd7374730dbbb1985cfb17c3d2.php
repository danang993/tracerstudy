<?php $__env->startSection('content'); ?>
    <?php if(session()->has('failures')): ?>
        <div class="alert alert-danger border border-danger alert-dismissible" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
            </button>
            <table class="table table-bordered border-danger py-4">
                <thead>
                    <tr>
                        <th>Baris</th>
                        <th>Atribut</th>
                        <th>Error</th>
                        <th>Value</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = session('failures'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $failure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($failure->row()); ?></td>
                            <td><?php echo e($failure->attribute()); ?></td>
                            <td>
                                <ul>
                                    <?php $__currentLoopData = $failure->errors(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>
                            <td>
                                <ul>
                                    <?php $__currentLoopData = $failure->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($value); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <h5 class="card-title">Daftar Alumni</h5>
            <div class="card-actions">
                <button class="btn btn-secondary create-new btn-primary" type="button" data-bs-toggle="offcanvas"
                    data-bs-target="#offcanvasJurusan" aria-controls="offcanvasJurusan">
                    <span>
                        <i class="bx bx-plus me-1"></i>
                        <span class="d-none d-lg-inline-block">
                            Tambah Jurusan
                        </span>
                    </span>
                </button>
                <!-- Icon Dropdown -->
                <div class="btn-group">
                    <button type="button" class="btn btn-outline-primary btn-icon dropdown-toggle hide-arrow"
                        data-bs-toggle="dropdown">
                        <i class="bx bx-dots-vertical-rounded"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('major.file-export')); ?>">
                                <i class='bx bx-chevron-right scaleX-n1-rtl'></i>
                                Export
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="javascript:void(0);"
                                data-bs-toggle="modal" data-bs-target="#majorImportModal"><i
                                    class="bx bx-chevron-right scaleX-n1-rtl"></i>
                                Import
                            </a>
                        </li>
                        
                    </ul>
                </div>
            </div>
        </div>

        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <?php
                    $delete = 'major.destroy';
                    $offcanvasId = 'offcanvasJurusan';
                    $canEdit = true;
                    $canDelete = true;
                ?>
                <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve(['headers' => $headers,'data' => $data,'delete' => $delete,'offcanvasId' => $offcanvasId,'canEdit' => $canEdit,'canDelete' => $canDelete] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Table::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
            </div>
        </div>
        <!-- Offcanvas to form jurusan -->
        <?php if (isset($component)) { $__componentOriginala63d2deaeebad052e38c25322fcb5d14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala63d2deaeebad052e38c25322fcb5d14 = $attributes; } ?>
<?php $component = App\View\Components\Offcanvas::resolve(['title' => 'Form Jurusan','id' => 'offcanvasJurusan'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('offcanvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Offcanvas::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <form class="form-jurusan pt-0 fv-plugins-bootstrap5 fv-plugins-framework" id="jurusanForm"
                action="<?php echo e(route('major.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo $__env->make('components.fields', [
                    'label' => 'Nama Jurusan',
                    'name' => 'name',
                    'placeholder' => 'Rekayasa Perangkat Lunak',
                    'type' => 'text',
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.fields', [
                    'label' => 'Tahun Pergantian <span class="text-danger">"kosongkan apabila belum ada"</span>',
                    'name' => 'expired_year',
                    'placeholder' => '2024',
                    'type' => 'text',
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.fields', [
                    'label' => 'Lembaga',
                    'name' => 'type_school_id',
                    'type' => 'select',
                    'options' => $type_schools->map(function ($type_school) {
                            return '<option value="' . $type_school->id . '">' . $type_school->name . '</option>';
                        })->join(' '),
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <button type="submit" class="btn btn-primary me-sm-3 me-1 data-submit">Submit</button>
                <button type="reset" class="btn btn-label-secondary" data-bs-dismiss="offcanvas">Cancel</button>
            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala63d2deaeebad052e38c25322fcb5d14)): ?>
<?php $attributes = $__attributesOriginala63d2deaeebad052e38c25322fcb5d14; ?>
<?php unset($__attributesOriginala63d2deaeebad052e38c25322fcb5d14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala63d2deaeebad052e38c25322fcb5d14)): ?>
<?php $component = $__componentOriginala63d2deaeebad052e38c25322fcb5d14; ?>
<?php unset($__componentOriginala63d2deaeebad052e38c25322fcb5d14); ?>
<?php endif; ?>
    </div>




    <!-- Modal -->
    <div class="modal fade" id="majorImportModal" data-bs-backdrop="static" tabindex="-1">
        <div class="modal-dialog">
            <form class="modal-content" action="<?php echo e(route('major.file-import')); ?>" enctype="multipart/form-data"
                method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="majorImportModalTitle">Import Alumni</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col">
                            <table class="table table-bordered py-4">
                                <thead>
                                    <tr>
                                        <th colspan="5">urutan column excel</th>
                                    </tr>
                                    <tr>
                                        <th>Nama Jurusan</th>
                                        <th>Lembaga SMA/SMK</th>
                                        <th>Tahun Pergantian <br><span class="text-danger">"BOLEH DIKOSONGKAN"</span>
                                        </th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mb-3">
                            <label for="nameBackdrop" class="form-label">File Import</label>
                            <input type="file" id="nameBackdrop" class="form-control" placeholder="Enter File"
                                name="file">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>






    <?php $__env->startPush('addon-js'); ?>
        <?php if(session()->has('success')): ?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: "<?php echo e(session('success')); ?>",
                    showConfirmButton: true,
                    confirmButtonColor: "#ff6a00",
                })
            </script>
        <?php endif; ?>
        <script>
            $(document).ready(function() {
                $('#myTable').DataTable();
                <?php if($errors->has('file')): ?>
                    $('#majorImportModal').modal('show');
                <?php endif; ?>
                $(document).on('click', '.btn-edit', function() {
                    let id = $(this).data('id');
                    let url_edit = "<?php echo e(route('major.edit', ':id')); ?>";
                    let url_update = "<?php echo e(route('major.update', ':id')); ?>";
                    url_edit = url_edit.replace(':id', id);
                    url_update = url_update.replace(':id', id);

                    $.ajax({
                        url: url_edit,
                        type: 'GET',
                        dataType: 'JSON',
                        success: function(data) {
                            $('#jurusanForm').append('<?php echo method_field('PUT'); ?>');
                            $('#name').val(data.name);
                            $('#expired_year').val(data.expired_year);
                            $('#type_school_id').val(data.type_school_id);
                            $('#jurusanForm').attr('action', url_update);
                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
                });

                $('#offcanvasJurusan').on('hidden.bs.offcanvas', function() {
                    let url_store = "<?php echo e(route('major.store')); ?>";
                    if (!$(this).hasClass('show')) {
                        $('#jurusanForm')[0].reset();
                        $('#jurusanForm').attr('action', url_store);
                        $('#jurusanForm > input[name="_method"]').remove();
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/pages/admin/major/index.blade.php ENDPATH**/ ?>