<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('addon-css'); ?>
        <?php echo \Livewire\Livewire::styles(); ?>

    <?php $__env->stopPush(); ?>
    <section class="container p-4 max-w-7xl mx-auto">
        <div class="row mb-12">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('form-alumni', [
                'answers' => $answers,
                'personalData' => $personalData,
                'alumni' => $alumni,
                'majors' => $majors,
                'questions' => $questions,
                'isFinished' => $isFinished,
            ])->html();
} elseif ($_instance->childHasBeenRendered('5lB6POI')) {
    $componentId = $_instance->getRenderedChildComponentId('5lB6POI');
    $componentTag = $_instance->getRenderedChildComponentTagName('5lB6POI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5lB6POI');
} else {
    $response = \Livewire\Livewire::mount('form-alumni', [
                'answers' => $answers,
                'personalData' => $personalData,
                'alumni' => $alumni,
                'majors' => $majors,
                'questions' => $questions,
                'isFinished' => $isFinished,
            ]);
    $html = $response->html();
    $_instance->logRenderedChild('5lB6POI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </section>
    
    <?php $__env->startPush('addon-js'); ?>
        <?php echo \Livewire\Livewire::scripts(); ?>

    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', ['bgBody' => 'bg-primary-50', 'isNavbar' => false, 'isFooter' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/pages/alumni/index.blade.php ENDPATH**/ ?>