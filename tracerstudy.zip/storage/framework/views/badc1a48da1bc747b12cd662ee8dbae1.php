<div class="mb-3 fv-plugins-icon-container">
    <?php if(isset($label)): ?>
        <label class="form-label" for="<?php echo e($name); ?>"><?php echo $label; ?></label>
    <?php endif; ?>
    <?php if(isset($type)): ?>
        <?php switch($type):
            case ('text'): ?>
                <input type="text" class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="<?php echo e($name); ?>"
                    placeholder="<?php echo e($placeholder); ?>" name="<?php echo e($name); ?>" aria-label="<?php echo e($placeholder); ?>"
                    value="<?php echo e(old($name, $value ?? '')); ?>">
            <?php break; ?>

            <?php case ('email'): ?>
                <input type="email" class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="<?php echo e($name); ?>"
                    placeholder="<?php echo e($placeholder); ?>" name="<?php echo e($name); ?>" aria-label="<?php echo e($placeholder); ?>"
                    value="<?php echo old($name, $value ?? ''); ?>">
            <?php break; ?>

            <?php case ('number'): ?>
                <input type="number" class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="<?php echo e($name); ?>"
                    placeholder="<?php echo e($placeholder); ?>" name="<?php echo e($name); ?>" aria-label="<?php echo e($placeholder); ?>"
                    value="<?php echo old($name, $value ?? ''); ?>">
            <?php break; ?>

            <?php case ('month'): ?>
                <input type="month" class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="<?php echo e($name); ?>"
                    placeholder="<?php echo e($placeholder ?? ''); ?>" name="<?php echo e($name); ?>" aria-label="<?php echo e($placeholder ?? ''); ?>"
                    value="<?php echo old($name, $value ?? ''); ?>">
            <?php break; ?>

            <?php case ('year'): ?>
                <input type="number" class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="<?php echo e($name); ?>"
                    placeholder="<?php echo e($placeholder ?? ''); ?>" name="<?php echo e($name); ?>" aria-label="<?php echo e($placeholder ?? ''); ?>"
                    value="<?php echo old($name, $value ?? ''); ?>" min="1900" max="<?php echo e(date('Y')); ?>">
            <?php break; ?>

            <?php case ('date'): ?>
                <input type="date" class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="<?php echo e($name); ?>"
                    placeholder="<?php echo e($placeholder ?? ''); ?>" name="<?php echo e($name); ?>" aria-label="<?php echo e($placeholder ?? ''); ?>"
                    value="<?php echo old($name, $value ?? ''); ?>">
            <?php break; ?>

            <?php case ('password'): ?>
                <input type="password" class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="<?php echo e($name); ?>"
                    placeholder="<?php echo e($placeholder); ?>" name="<?php echo e($name); ?>" aria-label="<?php echo e($placeholder); ?>"
                    value="<?php echo old($name, $value ?? ''); ?>">
            <?php break; ?>

            <?php case ('select'): ?>
                <select name="<?php echo e($name); ?>" id="<?php echo e($name); ?>"
                    class="form-select <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    ">
                    <?php echo $options; ?>

                </select>
            <?php break; ?>

            <?php case ('textarea'): ?>
                <textarea id="<?php echo e($name); ?>" class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="<?php echo e($placeholder); ?>" aria-label="<?php echo e($placeholder); ?>" name="<?php echo e($name); ?>"
                    value="<?php echo e(old($name, $value ?? '')); ?>"></textarea>
            <?php break; ?>

            <?php default: ?>
        <?php endswitch; ?>
    <?php endif; ?>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="fv-plugins-message-container invalid-feedback">
            <?php echo e($message); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/components/fields.blade.php ENDPATH**/ ?>