<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            ©
            <script>
                document.write(new Date().getFullYear())
            </script>
            , develop with ❤️ by danang<a href="https://www.linkedin.com/in/danangprasetyo07/" target="_blank"
                class="footer-link fw-bolder"> prasetyo
                </a>
        </div>
        <div>


            <a href="#" class="footer-link me-4" data-bs-toggle="modal"
                data-bs-target="#modalScrollable">Documentation</a>
        </div>
    </div>
</footer>

<div class="modal fade" id="modalScrollable" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalScrollableTitle">Petunjuk Penggunaan Aplikasi Tracer Study</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" style="max-height:25rem;">
                <p>
                    Cras mattis consectetur purus sit amet fermentum. Cras justo odio, dapibus ac facilisis
                    in, egestas eget quam. Morbi leo risus, porta ac consectetur ac, vestibulum at eros.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Ya, Saya mengerti</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/partials/dash/footer.blade.php ENDPATH**/ ?>