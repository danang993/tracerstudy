<?php if(!isset($offcanvasId)): ?>
    <?php
        $offcanvasId = '';
    ?>
<?php endif; ?>
<div class="table-responsive text-nowrap">
    <table class="table table-bordered py-4" id="myTable">
        <thead>
            <tr>
                <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($header); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($canDelete || $canEdit): ?>
                    <th>actions</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr
                    class="
                <?php if(isset($row['active'])): ?>
                    <?php if(!$row['active']): ?> table-active <?php endif; ?>
                <?php endif; ?>
                ">
                    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $lastActive = array_key_exists('active', $row);
                            // dd($last);
                        ?>
                        <?php if($lastActive): ?>
                            <?php if($cell != $loop->first && $cell != $loop->last): ?>
                                <td>
                                    <?php echo $cell; ?>

                                </td>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($cell != $loop->first): ?>
                                <td>
                                    <?php echo $cell; ?>

                                </td>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if($canDelete || $canEdit || $canShow): ?>
                        <td>
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                    data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button>
                                <div class="dropdown-menu">
                                    <?php if($canShow): ?>
                                        <a href="<?php echo e(route($show, $row[0])); ?>" class="dropdown-item"><i
                                                class="bx bx-show me-1"></i>
                                            Show
                                        </a>
                                    <?php endif; ?>
                                    <?php if($canEdit): ?>
                                        <button type="button" class="btn-edit dropdown-item" data-bs-toggle="offcanvas"
                                            data-bs-target="#<?php echo e($offcanvasId); ?>" aria-controls="offcanvasEnd"
                                            data-id="<?php echo e($row[0]); ?>"><i class="bx bx-edit-alt me-1"></i>
                                            Edit
                                        </button>
                                    <?php endif; ?>
                                    <?php if($canDelete): ?>
                                        <form action="<?php echo e(route($delete, $row[0])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="dropdown-item">
                                                <i class="bx bx-trash me-1"></i>
                                                Delete
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/components/table.blade.php ENDPATH**/ ?>