<?php $__env->startSection('title'); ?>
    Login Alumni | Tracer Study
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-col lg:flex-row h-screen items-center">
        <!-- Bagian kiri -->
        <div class="bg-primary-50 hidden lg:flex justify-center items-center w-full lg:w-1/2 xl:w-2/3 h-screen">
            <img data-aos="zoom-in" class="w-2/3" src="<?php echo e(asset('assets/img/illustrations/Graduation-bro.svg')); ?>">
        </div>

        <!-- Bagian kanan -->
        <div class="bg-white w-full lg:w-1/2 xl:w-1/3 h-screen lg:h-auto flex items-center lg:px-7 sm:px-32">
            <div data-aos="fade-up" class="p-16 sm:p-0 lg:p-20 xl:p-20 w-full">
                <!-- Header -->
                <div class="flex justify-center items-center mb-8">
                    <img class="h-20 w-20
                    " src="<?php echo e(asset('assets/logo/logo.png')); ?>" alt="">
                    <div class="flex flex-col">
                        <h1 class="text-3xl text-secondary font-bold">Tracer Study</h1>
                        <h1 class="text-3xl text-primary font-bold">SMK Muhammadiyah Loa Janan</h1>
                    </div>
                </div>
                <form action="<?php echo e(route('auth.login')); ?> " method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4">
                        <label for="nik" class="label">NIK</label>
                        <input type="text" id="nik" name="nik" placeholder="Masukkan NIK Anda"
                            class="form-control focus:shadow-outline">
                    </div>
                    <div class="mt-6 mb-4">
                        <label class="label">
                            <span>Google RECAPTCHA</span>
                        </label>

                        <?php echo NoCaptcha::renderJs(); ?>

                        <?php echo NoCaptcha::display(); ?>

                    </div>
                    <div class="mb-8">
                        <label for="remember" class="inline-flex items-center">
                            <input type="checkbox" id="remember" name="remember" class="form-checkbox  text-primary-600">
                            <span class="ml-2 text-gray-600">Remember Me</span>
                        </label>
                    </div>
                    <button type="submit" class="btn btn-primary w-full mb-4">Masuk</button>
                    <a href="/" class="btn btn-outline-secondary w-full">Kembali</a>
                </form>
                <hr class="my-8">
                
            </div>
        </div>

    </div>

    

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/pages/auth/alumni/login.blade.php ENDPATH**/ ?>