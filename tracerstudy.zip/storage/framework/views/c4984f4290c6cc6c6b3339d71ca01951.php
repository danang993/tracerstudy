<div class="offcanvas offcanvas-end <?php if($errors->any() && !session()->has('failures') && !$errors->has('file')): ?> show <?php endif; ?>" tabindex="-1" id="<?php echo e($id); ?>">
    <div class="offcanvas-header">
        <h5 id="<?php echo e($id); ?>Label" class="offcanvas-title"><?php echo e($title); ?></h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body mx-0 flex-grow-0">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/components/offcanvas.blade.php ENDPATH**/ ?>