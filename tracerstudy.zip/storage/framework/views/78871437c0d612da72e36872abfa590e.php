<div class="mb-4 radio">
    <label class="form-label"><?php echo e($question->name); ?></label>
    <?php $__currentLoopData = $question->optionInputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="<?php echo e($option->name); ?>" value="<?php echo e($option->id); ?>">
            <label class="form-check-label"><?php echo e($option->name); ?></label>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/partials/dash/question/radio.blade.php ENDPATH**/ ?>