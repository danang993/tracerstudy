<div class="form-check mb-4">
    <label for="status" class="label block mb-2">
        <?php echo e($question->name); ?>

    </label>
    <?php $__currentLoopData = $question->optionInputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex ml-6">
            <input
                class="hover:cursor-pointer absolute mt-1 -ml-6 appearance-none checked:bg-primary hover:checked:bg-primary-400 <?php $__errorArgs = [$wireModel];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> radio-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                type="radio" name="<?php echo e($question->id); ?>" id="<?php echo e($option->name); ?>" wire:model="<?php echo e($wireModel); ?>"
                value="<?php echo e($option->name); ?>" <?php if($fill == $option->name): echo 'checked'; endif; ?> for="<?php echo e($option->name); ?>">
            <label class="hover:cursor-pointer inline-block text-gray-500 mb-0" for="<?php echo e($option->name); ?>">
                <?php echo e($option->name); ?>

            </label>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__errorArgs = [$wireModel];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <label class="label">
            <span class="label-text-alt"><?php echo e($message); ?></span>
        </label>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/partials/field/radio.blade.php ENDPATH**/ ?>