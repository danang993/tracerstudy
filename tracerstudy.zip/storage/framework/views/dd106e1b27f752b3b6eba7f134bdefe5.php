<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.dash.total-alumni', [
        'currently_filling' => $currently_filling,
        'finished_filling' => $finished_filling,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(session()->has('failures')): ?>
        <div class="alert alert-danger border border-danger alert-dismissible" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
            </button>
            <table class="table table-bordered border-danger py-4">
                <thead>
                    <tr>
                        <th>Baris</th>
                        <th>Atribut</th>
                        <th>Error</th>
                        <th>Value</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = session('failures'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $failure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($failure->row()); ?></td>
                            <td><?php echo e($failure->attribute()); ?></td>
                            <td>
                                <ul>
                                    <?php $__currentLoopData = $failure->errors(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>
                            <td>
                                <ul>
                                    <?php $__currentLoopData = $failure->values(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($value); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>


    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <h5 class="card-title">Daftar Alumni</h5>
            <div class="card-actions">
                <button class="btn btn-secondary create-new btn-primary" type="button" data-bs-toggle="offcanvas"
                    data-bs-target="#offcanvasAlumni" aria-controls="offcanvasAlumni">
                    <span>
                        <i class="bx bx-plus me-1"></i>
                        <span class="d-none d-lg-inline-block">
                            Tambah Alumni
                        </span>
                    </span>
                </button>
                <!-- Icon Dropdown -->
                <div class="btn-group">
                    <button type="button" class="btn btn-outline-primary btn-icon dropdown-toggle hide-arrow"
                        data-bs-toggle="dropdown">
                        <i class="bx bx-dots-vertical-rounded"></i>
                    </button>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('alumni.file-export')); ?>">
                                <i class='bx bx-chevron-right scaleX-n1-rtl'></i>
                                Export
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="javascript:void(0);"
                                data-bs-toggle="modal" data-bs-target="#alumniImportModal"><i
                                    class="bx bx-chevron-right scaleX-n1-rtl"></i>
                                Import
                            </a>
                        </li>
                        
                    </ul>
                </div>
            </div>
        </div>

        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <?php
                    $delete = 'user.destroy';
                    $show = 'user.show';
                    $canShow = true;
                    $canDelete = false;
                    $offcanvasId = 'offcanvasAlumni';
                ?>
                <?php if (isset($component)) { $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f = $attributes; } ?>
<?php $component = App\View\Components\Table::resolve(['headers' => $headers,'data' => $data,'delete' => $delete,'offcanvasId' => $offcanvasId,'canShow' => $canShow,'show' => $show,'canDelete' => $canDelete] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Table::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $attributes = $__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__attributesOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f)): ?>
<?php $component = $__componentOriginal7d9f6e0b9001f5841f72577781b2d17f; ?>
<?php unset($__componentOriginal7d9f6e0b9001f5841f72577781b2d17f); ?>
<?php endif; ?>
            </div>
        </div>
        <!-- Offcanvas to form alumni -->
        <?php if (isset($component)) { $__componentOriginala63d2deaeebad052e38c25322fcb5d14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala63d2deaeebad052e38c25322fcb5d14 = $attributes; } ?>
<?php $component = App\View\Components\Offcanvas::resolve(['title' => 'Form Alumni','id' => 'offcanvasAlumni'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('offcanvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Offcanvas::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <form class="form-alumni pt-0 fv-plugins-bootstrap5 fv-plugins-framework" id="alumniForm"
                action="<?php echo e(route('user.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo $__env->make('components.fields', [
                    'label' => 'Nama Lengkap',
                    'name' => 'name',
                    'placeholder' => 'Danang Prasetyo',
                    'type' => 'text',
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.fields', [
                    'label' => 'Email',
                    'name' => 'email',
                    'placeholder' => 'danangp93@gmail.com',
                    'type' => 'email',
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.fields', [
                    'label' => 'NIK',
                    'name' => 'nik',
                    'placeholder' => '64720XXXXXXXXXXX',
                    'type' => 'text',
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.fields', [
                    'label' => 'Lembaga',
                    'name' => 'type_school_id',
                    'type' => 'select',
                    'options' => $type_schools->map(function ($type_school) {
                            return '<option value="' . $type_school->id . '">' . $type_school->name . '</option>';
                        })->join(' '),
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('components.fields', [
                    'label' => 'Tahun Angkatan',
                    'name' => 'grade_at',
                    'placeholder' => '2024/2025',
                    'type' => 'text',
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <button type="submit" class="btn btn-primary me-sm-3 me-1 data-submit">Submit</button>
                <button type="reset" class="btn btn-label-secondary" data-bs-dismiss="offcanvas">Cancel</button>
            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala63d2deaeebad052e38c25322fcb5d14)): ?>
<?php $attributes = $__attributesOriginala63d2deaeebad052e38c25322fcb5d14; ?>
<?php unset($__attributesOriginala63d2deaeebad052e38c25322fcb5d14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala63d2deaeebad052e38c25322fcb5d14)): ?>
<?php $component = $__componentOriginala63d2deaeebad052e38c25322fcb5d14; ?>
<?php unset($__componentOriginala63d2deaeebad052e38c25322fcb5d14); ?>
<?php endif; ?>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="alumniImportModal" data-bs-backdrop="static" tabindex="-1">
        <div class="modal-dialog">
            <form class="modal-content" action="<?php echo e(route('alumni.file-import')); ?>" enctype="multipart/form-data"
                method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="backDropModalTitle">Import Alumni</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col">
                            <table class="table table-bordered py-4">
                                <thead>
                                    <tr>
                                        <th colspan="5">urutan column excel</th>
                                    </tr>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Email</th>
                                        <th>NIK</th>
                                        <th>Lembaga</th>
                                        <th>Angkatan</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mb-3">
                            <label for="nameBackdrop" class="form-label">File Import</label>
                            <input type="file" id="nameBackdrop" class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                placeholder="Enter File" name="file">
                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>

    <div class="modal fade" id="attachMailModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel1">Mengirim Email Ke Alumni</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col mb-3">
                            <input type="hidden" name="emailForSend" id="emailForSend">
                            <label for="message" class="form-label">Sampaikan Pesan:</label>
                            <textarea name="message" id="message" class="form-control" placeholder="message"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-label-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="submitMail btn btn-primary">Send Email</button>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('addon-js'); ?>
        <?php if(session()->has('success')): ?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: "<?php echo e(session('success')); ?>",
                    showConfirmButton: true,
                    confirmButtonColor: "#ff6a00",
                })
            </script>
        <?php endif; ?>
        <script>
            $(document).on('click', '.sendMail', function() {
                let user = $(this).data('user');
                $('#emailForSend').val(user.email);
                // $('#attachMailModal').find('.modal-title').append('Mengirim Email Ke ' + $('#emailForSend').val());
            });

            $(document).on('click', '.submitMail', function() {
                let data = {};
                data.email = $('#emailForSend').val();
                data.message = $('#message').val();
                data._token = '<?php echo e(csrf_token()); ?>';
                $.ajax({
                    url: "<?php echo e(route('sendMail')); ?>",
                    type: 'POST',
                    dataType: 'JSON',
                    data: data,
                    success: function(data) {
                        console.log(data);
                        $('#attachMailModal').removeClass('fade')
                        $(".modal-backdrop").remove();
                        $('#attachMailMoal').hide();
                        $('.user-send').remove();
                    },
                    error: function(xhr) {
                        console.log(xhr.responseText);
                    },
                })
            });




            $(document).ready(function() {
                $('#myTable').DataTable();
                <?php if($errors->has('file')): ?>
                    $('#alumniImportModal').modal('show');
                <?php endif; ?>
                $(document).on('click', '.btn-edit', function() {
                    let id = $(this).data('id');
                    let url_edit = "<?php echo e(route('user.edit', ':id')); ?>";
                    let url_update = "<?php echo e(route('user.update', ':id')); ?>";
                    url_edit = url_edit.replace(':id', id);
                    url_update = url_update.replace(':id', id);

                    $.ajax({
                        url: url_edit,
                        type: 'GET',
                        dataType: 'JSON',
                        success: function(data) {
                            $('#alumniForm').append('<?php echo method_field('PUT'); ?>');
                            $('#name').val(data.name);
                            $('#email').val(data.email);
                            $('#nik').val(data.nik);
                            $('#type_school_id').val(data.type_school_id);
                            $('#grade_at').val(data.grade_at);
                            $('#alumniForm').attr('action', url_update);
                        },
                        error: function(xhr) {
                            console.log(xhr.responseText);
                        }
                    });
                });

                $('#offcanvasAlumni').on('hidden.bs.offcanvas', function() {
                    let url_store = "<?php echo e(route('user.store')); ?>";
                    if (!$(this).hasClass('show')) {
                        $('#alumniForm')[0].reset();
                        $('#alumniForm').attr('action', url_store);
                        $('#alumniForm > input[name="_method"]').remove();
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/pages/admin/user/index.blade.php ENDPATH**/ ?>