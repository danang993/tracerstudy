<div class="mb-4">
    <label class="form-label"><?php echo e($question->name); ?></label>
    <input type="text" class="form-control">
</div>
<?php /**PATH C:\xampp\htdocs\tracerstudy\resources\views/partials/dash/question/text.blade.php ENDPATH**/ ?>